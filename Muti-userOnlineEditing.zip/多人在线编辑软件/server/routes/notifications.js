const express = require('express');
const Notification = require('../models/Notification');
const router = express.Router();

// 获取用户通知
router.get('/', async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      type,
      isRead,
      sortBy = 'createdAt',
      sortOrder = 'desc'
    } = req.query;
    
    const userId = req.user.id;
    const query = { recipient: userId };
    
    // 类型过滤
    if (type) {
      query.type = type;
    }
    
    // 已读状态过滤
    if (isRead !== undefined) {
      query.isRead = isRead === 'true';
    }
    
    // 排序选项
    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;
    
    const notifications = await Notification.find(query)
      .populate('sender', 'username avatar')
      .populate('recipient', 'username avatar')
      .populate('relatedDocument', 'title')
      .sort(sortOptions)
      .limit(limit * 1)
      .skip((page - 1) * limit);
      
    const count = await Notification.countDocuments(query);
    
    res.json({
      notifications,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
      totalNotifications: count
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 获取单个通知详情
router.get('/:id', async (req, res) => {
  try {
    const userId = req.user.id;
    
    const notification = await Notification.findById(req.params.id)
      .populate('sender', 'username avatar')
      .populate('recipient', 'username avatar')
      .populate('relatedDocument', 'title');
    
    if (!notification) {
      return res.status(404).json({ message: '通知不存在' });
    }
    
    // 检查权限
    if (notification.recipient._id.toString() !== userId) {
      return res.status(403).json({ message: '没有访问权限' });
    }
    
    res.json({ notification });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 标记通知为已读
router.put('/:id/read', async (req, res) => {
  try {
    const userId = req.user.id;
    
    const notification = await Notification.findById(req.params.id);
    
    if (!notification) {
      return res.status(404).json({ message: '通知不存在' });
    }
    
    // 检查权限
    if (notification.recipient.toString() !== userId) {
      return res.status(403).json({ message: '没有操作权限' });
    }
    
    // 标记为已读
    notification.isRead = true;
    await notification.save();
    
    // 填充关联数据
    await notification.populate('sender', 'username avatar');
    await notification.populate('relatedDocument', 'title');
    
    res.json({
      message: '通知已标记为已读',
      notification
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 标记所有通知为已读
router.put('/read-all', async (req, res) => {
  try {
    const userId = req.user.id;
    
    await Notification.updateMany(
      { recipient: userId, isRead: false },
      { isRead: true }
    );
    
    res.json({ message: '所有通知已标记为已读' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 删除通知
router.delete('/:id', async (req, res) => {
  try {
    const userId = req.user.id;
    
    const notification = await Notification.findById(req.params.id);
    
    if (!notification) {
      return res.status(404).json({ message: '通知不存在' });
    }
    
    // 检查权限
    if (notification.recipient.toString() !== userId) {
      return res.status(403).json({ message: '没有操作权限' });
    }
    
    await Notification.findByIdAndDelete(req.params.id);
    
    res.json({ message: '通知删除成功' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 获取未读通知数量
router.get('/unread/count', async (req, res) => {
  try {
    const userId = req.user.id;
    
    const count = await Notification.countDocuments({
      recipient: userId,
      isRead: false
    });
    
    res.json({ unreadCount: count });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

module.exports = router;