const express = require('express');
const Document = require('../models/Document');
const Folder = require('../models/Folder');
const Notification = require('../models/Notification');
const router = express.Router();

// 获取所有文档 (支持分页、搜索和过滤)
router.get('/', async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      search,
      type,
      folder,
      tags,
      sortBy = 'updatedAt',
      sortOrder = 'desc'
    } = req.query;
    
    const userId = req.user.id;
    const query = {
      $or: [
        { owner: userId },
        { 'collaborators.user': userId },
        { isPublic: true }
      ]
    };
    
    // 搜索过滤
    if (search) {
      query.$text = { $search: search };
    }
    
    // 类型过滤
    if (type) {
      query.type = type;
    }
    
    // 文件夹过滤
    if (folder) {
      query.folder = folder === 'null' ? null : folder;
    }
    
    // 标签过滤
    if (tags) {
      const tagsArray = tags.split(',').map(tag => tag.trim());
      query.tags = { $in: tagsArray };
    }
    
    // 排序选项
    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;
    
    const documents = await Document.find(query)
      .populate('owner', 'username avatar')
      .populate('collaborators.user', 'username avatar')
      .populate('lastEditedBy', 'username avatar')
      .populate('folder', 'name')
      .sort(sortOptions)
      .limit(limit * 1)
      .skip((page - 1) * limit);
      
    const count = await Document.countDocuments(query);
    
    res.json({
      documents,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
      totalDocuments: count
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 获取单个文档详情
router.get('/:id', async (req, res) => {
  try {
    const userId = req.user.id;
    
    const document = await Document.findById(req.params.id)
      .populate('owner', 'username avatar')
      .populate('collaborators.user', 'username avatar')
      .populate('lastEditedBy', 'username avatar')
      .populate('folder', 'name')
      .populate('comments.author', 'username avatar')
      .populate('comments.replies.author', 'username avatar')
      .populate('tasks.assignedTo', 'username avatar')
      .populate('tasks.createdBy', 'username avatar');
    
    if (!document) {
      return res.status(404).json({ message: '文档不存在' });
    }
    
    // 检查用户权限
    const isOwner = document.owner._id.toString() === userId;
    const isCollaborator = document.collaborators.some(
      c => c.user._id.toString() === userId
    );
    const isPublic = document.isPublic;
    
    if (!isOwner && !isCollaborator && !isPublic) {
      return res.status(403).json({ message: '没有访问权限' });
    }
    
    res.json({ document });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 创建新文档
router.post('/', async (req, res) => {
  try {
    const { title, content, type, tags, folder, isPublic } = req.body;
    const userId = req.user.id;
    
    // 验证必填字段
    if (!title) {
      return res.status(400).json({ message: '标题是必填项' });
    }
    
    // 如果指定了文件夹，验证用户是否有访问权限
    if (folder) {
      const folderDoc = await Folder.findById(folder);
      if (!folderDoc || (folderDoc.owner.toString() !== userId && !folderDoc.isPublic)) {
        return res.status(403).json({ message: '没有访问指定文件夹的权限' });
      }
    }
    
    const newDocument = new Document({
      title,
      content: content || '',
      type: type || 'text',
      tags: tags || [],
      folder: folder || null,
      isPublic: isPublic || false,
      owner: userId,
      lastEditedBy: userId
    });
    
    await newDocument.save();
    
    // 填充关联数据
    await newDocument.populate('owner', 'username avatar');
    await newDocument.populate('lastEditedBy', 'username avatar');
    if (newDocument.folder) {
      await newDocument.populate('folder', 'name');
    }
    
    res.status(201).json({
      message: '文档创建成功',
      document: newDocument
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 更新文档
router.put('/:id', async (req, res) => {
  try {
    const { title, content, type, tags, folder, isPublic } = req.body;
    const userId = req.user.id;
    
    // 获取文档
    const document = await Document.findById(req.params.id);
    
    if (!document) {
      return res.status(404).json({ message: '文档不存在' });
    }
    
    // 检查权限
    const isOwner = document.owner.toString() === userId;
    const writePermission = document.collaborators.some(
      c => c.user.toString() === userId && ['write', 'admin'].includes(c.permission)
    );
    
    if (!isOwner && !writePermission) {
      return res.status(403).json({ message: '没有编辑权限' });
    }
    
    // 如果指定了文件夹，验证用户是否有访问权限
    if (folder !== undefined && folder !== document.folder.toString()) {
      if (folder) {
        const folderDoc = await Folder.findById(folder);
        if (!folderDoc || (folderDoc.owner.toString() !== userId && !folderDoc.isPublic)) {
          return res.status(403).json({ message: '没有访问指定文件夹的权限' });
        }
      }
    }
    
    // 更新文档
    if (title !== undefined) document.title = title;
    if (content !== undefined) document.content = content;
    if (type !== undefined) document.type = type;
    if (tags !== undefined) document.tags = tags;
    if (folder !== undefined) document.folder = folder;
    if (isPublic !== undefined) document.isPublic = isPublic;
    
    document.lastEditedBy = userId;
    document.lastEditedAt = new Date();
    
    await document.save();
    
    // 填充关联数据
    await document.populate('owner', 'username avatar');
    await document.populate('lastEditedBy', 'username avatar');
    if (document.folder) {
      await document.populate('folder', 'name');
    }
    
    res.json({
      message: '文档更新成功',
      document
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 删除文档
router.delete('/:id', async (req, res) => {
  try {
    const userId = req.user.id;
    
    const document = await Document.findById(req.params.id);
    
    if (!document) {
      return res.status(404).json({ message: '文档不存在' });
    }
    
    // 检查权限 (只有所有者和管理员协作者可以删除)
    const isOwner = document.owner.toString() === userId;
    const adminPermission = document.collaborators.some(
      c => c.user.toString() === userId && c.permission === 'admin'
    );
    
    if (!isOwner && !adminPermission) {
      return res.status(403).json({ message: '没有删除权限' });
    }
    
    await Document.findByIdAndDelete(req.params.id);
    
    res.json({ message: '文档删除成功' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 添加协作者
router.post('/:id/collaborators', async (req, res) => {
  try {
    const { userId: collaboratorId, permission = 'read' } = req.body;
    const currentUserId = req.user.id;
    
    // 验证权限级别
    if (!['read', 'write', 'admin'].includes(permission)) {
      return res.status(400).json({ message: '无效的权限级别' });
    }
    
    // 获取文档
    const document = await Document.findById(req.params.id);
    
    if (!document) {
      return res.status(404).json({ message: '文档不存在' });
    }
    
    // 检查权限 (只有所有者和管理员协作者可以添加协作者)
    const isOwner = document.owner.toString() === currentUserId;
    const adminPermission = document.collaborators.some(
      c => c.user.toString() === currentUserId && c.permission === 'admin'
    );
    
    if (!isOwner && !adminPermission) {
      return res.status(403).json({ message: '没有添加协作者的权限' });
    }
    
    // 检查用户是否已经是协作者
    const existingCollaborator = document.collaborators.find(
      c => c.user.toString() === collaboratorId
    );
    
    if (existingCollaborator) {
      return res.status(409).json({ message: '该用户已经是协作者' });
    }
    
    // 检查是否尝试添加文档所有者作为协作者
    if (document.owner.toString() === collaboratorId) {
      return res.status(400).json({ message: '不能将文档所有者添加为协作者' });
    }
    
    // 添加协作者
    document.collaborators.push({
      user: collaboratorId,
      permission
    });
    
    await document.save();
    
    // 创建通知
    const notification = new Notification({
      recipient: collaboratorId,
      sender: currentUserId,
      type: 'document_share',
      title: '文档分享',
      message: `${req.user.username} 与您分享了文档 "${document.title}"`,
      relatedDocument: document._id
    });
    
    await notification.save();
    
    // 填充协作者信息
    await document.populate('collaborators.user', 'username avatar');
    
    res.status(201).json({
      message: '协作者添加成功',
      collaborator: document.collaborators.find(
        c => c.user._id.toString() === collaboratorId
      )
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 更新协作者权限
router.put('/:id/collaborators/:collaboratorId', async (req, res) => {
  try {
    const { permission } = req.body;
    const currentUserId = req.user.id;
    
    // 验证权限级别
    if (!['read', 'write', 'admin'].includes(permission)) {
      return res.status(400).json({ message: '无效的权限级别' });
    }
    
    // 获取文档
    const document = await Document.findById(req.params.id);
    
    if (!document) {
      return res.status(404).json({ message: '文档不存在' });
    }
    
    // 检查权限 (只有所有者和管理员协作者可以更新协作者权限)
    const isOwner = document.owner.toString() === currentUserId;
    const adminPermission = document.collaborators.some(
      c => c.user.toString() === currentUserId && c.permission === 'admin'
    );
    
    if (!isOwner && !adminPermission) {
      return res.status(403).json({ message: '没有更新协作者权限的权限' });
    }
    
    // 查找并更新协作者权限
    const collaboratorIndex = document.collaborators.findIndex(
      c => c.user.toString() === req.params.collaboratorId
    );
    
    if (collaboratorIndex === -1) {
      return res.status(404).json({ message: '协作者不存在' });
    }
    
    document.collaborators[collaboratorIndex].permission = permission;
    await document.save();
    
    // 填充协作者信息
    await document.populate('collaborators.user', 'username avatar');
    
    res.json({
      message: '协作者权限更新成功',
      collaborator: document.collaborators[collaboratorIndex]
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 移除协作者
router.delete('/:id/collaborators/:collaboratorId', async (req, res) => {
  try {
    const currentUserId = req.user.id;
    
    // 获取文档
    const document = await Document.findById(req.params.id);
    
    if (!document) {
      return res.status(404).json({ message: '文档不存在' });
    }
    
    // 检查权限
    const isOwner = document.owner.toString() === currentUserId;
    const isAdmin = document.collaborators.some(
      c => c.user.toString() === currentUserId && c.permission === 'admin'
    );
    const isSelfRemoving = req.params.collaboratorId === currentUserId;
    
    if (!isOwner && !isAdmin && !isSelfRemoving) {
      return res.status(403).json({ message: '没有移除协作者的权限' });
    }
    
    // 查找并移除协作者
    const collaboratorIndex = document.collaborators.findIndex(
      c => c.user.toString() === req.params.collaboratorId
    );
    
    if (collaboratorIndex === -1) {
      return res.status(404).json({ message: '协作者不存在' });
    }
    
    document.collaborators.splice(collaboratorIndex, 1);
    await document.save();
    
    res.json({ message: '协作者移除成功' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 添加评论
router.post('/:id/comments', async (req, res) => {
  try {
    const { content, position } = req.body;
    const userId = req.user.id;
    
    // 验证必填字段
    if (!content) {
      return res.status(400).json({ message: '评论内容是必填项' });
    }
    
    // 获取文档
    const document = await Document.findById(req.params.id);
    
    if (!document) {
      return res.status(404).json({ message: '文档不存在' });
    }
    
    // 检查权限
    const isOwner = document.owner.toString() === userId;
    const isCollaborator = document.collaborators.some(
      c => c.user.toString() === userId
    );
    const isPublic = document.isPublic;
    
    if (!isOwner && !isCollaborator && !isPublic) {
      return res.status(403).json({ message: '没有访问权限' });
    }
    
    // 添加评论
    const newComment = {
      author: userId,
      content,
      position
    };
    
    document.comments.push(newComment);
    await document.save();
    
    // 如果评论中提到了其他用户，创建通知
    const mentionRegex = /@(\w+)/g;
    const mentions = content.match(mentionRegex);
    
    if (mentions) {
      // 这里可以添加逻辑来查找被提及的用户并创建通知
      // 为了简化，我们暂时跳过这个功能
    }
    
    // 填充评论信息
    await document.populate('comments.author', 'username avatar');
    
    const addedComment = document.comments[document.comments.length - 1];
    
    // 创建通知给文档所有者
    if (document.owner.toString() !== userId) {
      const notification = new Notification({
        recipient: document.owner,
        sender: userId,
        type: 'comment',
        title: '新评论',
        message: `${req.user.username} 在您的文档 "${document.title}" 中添加了评论`,
        relatedDocument: document._id
      });
      
      await notification.save();
    }
    
    res.status(201).json({
      message: '评论添加成功',
      comment: addedComment
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 添加任务
router.post('/:id/tasks', async (req, res) => {
  try {
    const { title, description, assignedTo, dueDate } = req.body;
    const userId = req.user.id;
    
    // 验证必填字段
    if (!title) {
      return res.status(400).json({ message: '任务标题是必填项' });
    }
    
    // 获取文档
    const document = await Document.findById(req.params.id);
    
    if (!document) {
      return res.status(404).json({ message: '文档不存在' });
    }
    
    // 检查权限
    const isOwner = document.owner.toString() === userId;
    const writePermission = document.collaborators.some(
      c => c.user.toString() === userId && ['write', 'admin'].includes(c.permission)
    );
    
    if (!isOwner && !writePermission) {
      return res.status(403).json({ message: '没有添加任务的权限' });
    }
    
    // 添加任务
    const newTask = {
      title,
      description: description || '',
      assignedTo: assignedTo || null,
      createdBy: userId,
      dueDate: dueDate || null
    };
    
    document.tasks.push(newTask);
    await document.save();
    
    // 填充任务信息
    await document.populate('tasks.assignedTo', 'username avatar');
    await document.populate('tasks.createdBy', 'username avatar');
    
    const addedTask = document.tasks[document.tasks.length - 1];
    
    // 创建通知给被分配的用户
    if (assignedTo && assignedTo !== userId) {
      const notification = new Notification({
        recipient: assignedTo,
        sender: userId,
        type: 'task_assigned',
        title: '新任务分配',
        message: `${req.user.username} 在文档 "${document.title}" 中为您分配了任务: "${title}"`,
        relatedDocument: document._id
      });
      
      await notification.save();
    }
    
    res.status(201).json({
      message: '任务添加成功',
      task: addedTask
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

// 更新任务状态
router.put('/:id/tasks/:taskId', async (req, res) => {
  try {
    const { status } = req.body;
    const userId = req.user.id;
    
    // 验证状态值
    if (!['todo', 'in-progress', 'completed'].includes(status)) {
      return res.status(400).json({ message: '无效的任务状态' });
    }
    
    // 获取文档
    const document = await Document.findById(req.params.id);
    
    if (!document) {
      return res.status(404).json({ message: '文档不存在' });
    }
    
    // 查找任务
    const taskIndex = document.tasks.findIndex(
      t => t._id.toString() === req.params.taskId
    );
    
    if (taskIndex === -1) {
      return res.status(404).json({ message: '任务不存在' });
    }
    
    const task = document.tasks[taskIndex];
    
    // 检查权限 (任务创建者、被分配者、文档所有者或管理员协作者可以更新任务状态)
    const isOwner = document.owner.toString() === userId;
    const isTaskCreator = task.createdBy.toString() === userId;
    const isAssignee = task.assignedTo && task.assignedTo.toString() === userId;
    const isAdmin = document.collaborators.some(
      c => c.user.toString() === userId && c.permission === 'admin'
    );
    
    if (!isOwner && !isTaskCreator && !isAssignee && !isAdmin) {
      return res.status(403).json({ message: '没有更新任务状态的权限' });
    }
    
    // 更新任务状态
    const oldStatus = task.status;
    task.status = status;
    
    await document.save();
    
    // 如果任务状态变为完成，创建通知
    if (status === 'completed' && oldStatus !== 'completed') {
      // 通知任务创建者
      if (task.createdBy.toString() !== userId) {
        const notification = new Notification({
          recipient: task.createdBy,
          sender: userId,
          type: 'task_completed',
          title: '任务已完成',
          message: `${req.user.username} 完成了任务: "${task.title}"`,
          relatedDocument: document._id
        });
        
        await notification.save();
      }
      
      // 如果任务被分配给其他人，也通知被分配者
      if (task.assignedTo && 
          task.assignedTo.toString() !== userId && 
          task.assignedTo.toString() !== task.createdBy.toString()) {
        const notification = new Notification({
          recipient: task.assignedTo,
          sender: userId,
          type: 'task_completed',
          title: '任务已完成',
          message: `${req.user.username} 完成了任务: "${task.title}"`,
          relatedDocument: document._id
        });
        
        await notification.save();
      }
    }
    
    // 填充任务信息
    await document.populate('tasks.assignedTo', 'username avatar');
    await document.populate('tasks.createdBy', 'username avatar');
    
    res.json({
      message: '任务状态更新成功',
      task: document.tasks[taskIndex]
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '服务器错误' });
  }
});

module.exports = router;