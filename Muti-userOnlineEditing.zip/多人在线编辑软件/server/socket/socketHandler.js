const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Document = require('../models/Document');

// 存储文档编辑状态
const documentEditSessions = new Map();
// 存储用户Socket ID映射
const userSockets = new Map();

const authenticateSocket = async (socket, next) => {
  try {
    const token = socket.handshake.auth.token;
    
    if (!token) {
      return next(new Error('认证失败：缺少令牌'));
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);
    
    if (!user) {
      return next(new Error('认证失败：用户不存在'));
    }
    
    socket.user = user;
    next();
  } catch (error) {
    next(new Error('认证失败：令牌无效'));
  }
};

const socketHandler = (io) => {
  io.use(authenticateSocket);
  
  io.on('connection', (socket) => {
    console.log(`用户 ${socket.user.username} 已连接`);
    
    // 存储用户Socket映射
    userSockets.set(socket.user.id, socket.id);
    
    // 加入用户的个人房间（用于私人通知）
    socket.join(`user:${socket.user.id}`);
    
    // 处理加入文档房间
    socket.on('join-document', async (data) => {
      try {
        const { documentId } = data;
        
        // 验证文档访问权限
        const document = await Document.findById(documentId);
        
        if (!document) {
          socket.emit('error', { message: '文档不存在' });
          return;
        }
        
        const userId = socket.user.id;
        const isOwner = document.owner.toString() === userId;
        const isCollaborator = document.collaborators.some(
          c => c.user.toString() === userId
        );
        const isPublic = document.isPublic;
        
        if (!isOwner && !isCollaborator && !isPublic) {
          socket.emit('error', { message: '没有访问权限' });
          return;
        }
        
        // 加入文档房间
        socket.join(documentId);
        
        // 初始化或获取文档编辑会话
        if (!documentEditSessions.has(documentId)) {
          documentEditSessions.set(documentId, {
            documentId,
            content: document.content,
            version: 0,
            users: new Map(),
            operations: []
          });
        }
        
        const session = documentEditSessions.get(documentId);
        
        // 记录用户信息
        session.users.set(userId, {
          id: userId,
          username: socket.user.username,
          avatar: socket.user.avatar,
          socketId: socket.id,
          cursor: { line: 0, column: 0 },
          color: getUserColor(userId),
          joinedAt: new Date()
        });
        
        // 向当前用户发送文档内容和当前编辑用户列表
        socket.emit('document-joined', {
          content: session.content,
          version: session.version,
          users: Array.from(session.users.values())
        });
        
        // 向房间内其他用户广播新用户加入
        socket.to(documentId).emit('user-joined', {
          user: {
            id: userId,
            username: socket.user.username,
            avatar: socket.user.avatar,
            color: getUserColor(userId)
          }
        });
        
        console.log(`用户 ${socket.user.username} 加入了文档 ${documentId}`);
      } catch (error) {
        console.error('加入文档错误:', error);
        socket.emit('error', { message: '加入文档失败' });
      }
    });
    
    // 处理文档内容变更
    socket.on('document-change', async (data) => {
      try {
        const { documentId, operation, version } = data;
        
        // 验证文档访问权限
        const document = await Document.findById(documentId);
        
        if (!document) {
          socket.emit('error', { message: '文档不存在' });
          return;
        }
        
        const userId = socket.user.id;
        const isOwner = document.owner.toString() === userId;
        const writePermission = document.collaborators.some(
          c => c.user.toString() === userId && ['write', 'admin'].includes(c.permission)
        );
        
        if (!isOwner && !writePermission) {
          socket.emit('error', { message: '没有编辑权限' });
          return;
        }
        
        const session = documentEditSessions.get(documentId);
        
        if (!session) {
          socket.emit('error', { message: '文档会话不存在' });
          return;
        }
        
        // 版本检查
        if (version !== session.version) {
          // 版本不匹配，发送最新内容
          socket.emit('document-sync', {
            content: session.content,
            version: session.version
          });
          return;
        }
        
        // 应用操作
        const newContent = applyOperation(session.content, operation);
        session.content = newContent;
        session.version += 1;
        
        // 保存操作记录
        session.operations.push({
          operation,
          userId,
          timestamp: new Date()
        });
        
        // 限制操作记录数量
        if (session.operations.length > 100) {
          session.operations = session.operations.slice(-50);
        }
        
        // 更新数据库中的文档内容
        await Document.findByIdAndUpdate(documentId, {
          content: newContent,
          lastEditedBy: userId,
          lastEditedAt: new Date()
        });
        
        // 向房间内其他用户广播变更
        socket.to(documentId).emit('document-changed', {
          operation,
          version: session.version,
          userId,
          username: socket.user.username
        });
        
      } catch (error) {
        console.error('文档变更错误:', error);
        socket.emit('error', { message: '文档变更失败' });
      }
    });
    
    // 处理光标位置更新
    socket.on('cursor-update', (data) => {
      try {
        const { documentId, cursor } = data;
        
        const session = documentEditSessions.get(documentId);
        if (!session) return;
        
        const userId = socket.user.id;
        const user = session.users.get(userId);
        
        if (user) {
          user.cursor = cursor;
          
          // 向房间内其他用户广播光标位置
          socket.to(documentId).emit('cursor-updated', {
            userId,
            username: socket.user.username,
            cursor,
            color: user.color
          });
        }
      } catch (error) {
        console.error('光标更新错误:', error);
      }
    });
    
    // 处理离开文档房间
    socket.on('leave-document', (data) => {
      try {
        const { documentId } = data;
        
        socket.leave(documentId);
        
        const session = documentEditSessions.get(documentId);
        if (session) {
          session.users.delete(socket.user.id);
          
          // 如果没有用户了，清理会话
          if (session.users.size === 0) {
            documentEditSessions.delete(documentId);
          } else {
            // 向房间内其他用户广播用户离开
            socket.to(documentId).emit('user-left', {
              userId: socket.user.id,
              username: socket.user.username
            });
          }
        }
        
        console.log(`用户 ${socket.user.username} 离开了文档 ${documentId}`);
      } catch (error) {
        console.error('离开文档错误:', error);
      }
    });
    
    // 处理实时聊天
    socket.on('chat-message', async (data) => {
      try {
        const { documentId, message } = data;
        
        // 验证文档访问权限
        const document = await Document.findById(documentId);
        
        if (!document) {
          socket.emit('error', { message: '文档不存在' });
          return;
        }
        
        const userId = socket.user.id;
        const isOwner = document.owner.toString() === userId;
        const isCollaborator = document.collaborators.some(
          c => c.user.toString() === userId
        );
        const isPublic = document.isPublic;
        
        if (!isOwner && !isCollaborator && !isPublic) {
          socket.emit('error', { message: '没有访问权限' });
          return;
        }
        
        const chatMessage = {
          id: new Date().getTime().toString(),
          userId,
          username: socket.user.username,
          avatar: socket.user.avatar,
          message,
          timestamp: new Date()
        };
        
        // 向文档房间内所有用户广播聊天消息
        io.to(documentId).emit('chat-message', chatMessage);
        
        console.log(`用户 ${socket.user.username} 在文档 ${documentId} 中发送消息: ${message}`);
      } catch (error) {
        console.error('聊天消息错误:', error);
        socket.emit('error', { message: '发送消息失败' });
      }
    });
    
    // 处理断开连接
    socket.on('disconnect', () => {
      console.log(`用户 ${socket.user.username} 已断开连接`);
      
      // 从用户Socket映射中删除
      userSockets.delete(socket.user.id);
      
      // 从所有文档会话中删除用户
      for (const [documentId, session] of documentEditSessions.entries()) {
        if (session.users.has(socket.user.id)) {
          session.users.delete(socket.user.id);
          
          // 如果没有用户了，清理会话
          if (session.users.size === 0) {
            documentEditSessions.delete(documentId);
          } else {
            // 向房间内其他用户广播用户离开
            socket.to(documentId).emit('user-left', {
              userId: socket.user.id,
              username: socket.user.username
            });
          }
        }
      }
    });
  });
};

// 为用户生成一致的颜色
const getUserColor = (userId) => {
  const colors = [
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
    '#DDA5E9', '#5F27CD', '#00D2D3', '#FF9FF3', '#54A0FF'
  ];
  
  let hash = 0;
  for (let i = 0; i < userId.length; i++) {
    hash = userId.charCodeAt(i) + ((hash << 5) - hash);
  }
  
  return colors[Math.abs(hash) % colors.length];
};

// 应用操作到内容
const applyOperation = (content, operation) => {
  // 这里简化处理，实际应用中应该使用 Operational Transform (OT) 或 CRDT 算法
  // 为了演示，我们只处理简单的文本插入和删除
  
  const { type, position, text, length } = operation;
  
  if (type === 'insert') {
    return content.slice(0, position) + text + content.slice(position);
  } else if (type === 'delete') {
    return content.slice(0, position) + content.slice(position + length);
  }
  
  return content;
};

module.exports = socketHandler;