import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  Box,
  Avatar,
  TextField,
  Button,
  Grid,
  IconButton,
  CircularProgress
} from '@mui/material';
import {
  PhotoCamera as PhotoCameraIcon,
  Save as SaveIcon
} from '@mui/icons-material';
import { useAuth } from '../../contexts/AuthContext';
import userService from '../../services/userService';

const Profile = () => {
  const { user, updateUser } = useAuth();
  const [formData, setFormData] = useState({
    username: '',
    email: ''
  });
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [avatarFile, setAvatarFile] = useState(null);
  const [previewImage, setPreviewImage] = useState('');
  const [loading, setLoading] = useState(false);
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (user) {
      setFormData({
        username: user.username,
        email: user.email
      });
      setPreviewImage(user.avatar || '');
    }
  }, [user]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // 清除该字段的错误
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  const handlePasswordInputChange = (e) => {
    const { name, value } = e.target;
    setPasswordData({
      ...passwordData,
      [name]: value
    });
    
    // 清除该字段的错误
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // 验证文件类型
      if (!file.type.match(/image\/(jpeg|jpg|png|gif)/)) {
        setErrors({
          ...errors,
          avatar: '只支持 JPEG、JPG、PNG 和 GIF 格式的图片'
        });
        return;
      }
      
      // 验证文件大小 (5MB)
      if (file.size > 5 * 1024 * 1024) {
        setErrors({
          ...errors,
          avatar: '图片大小不能超过 5MB'
        });
        return;
      }
      
      setAvatarFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const validateProfileForm = () => {
    const newErrors = {};
    
    if (!formData.username.trim()) {
      newErrors.username = '用户名不能为空';
    } else if (formData.username.length < 3) {
      newErrors.username = '用户名至少需要3个字符';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = '邮箱不能为空';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = '邮箱格式不正确';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validatePasswordForm = () => {
    const newErrors = {};
    
    if (!passwordData.currentPassword) {
      newErrors.currentPassword = '当前密码不能为空';
    }
    
    if (!passwordData.newPassword) {
      newErrors.newPassword = '新密码不能为空';
    } else if (passwordData.newPassword.length < 6) {
      newErrors.newPassword = '新密码至少需要6个字符';
    }
    
    if (!passwordData.confirmPassword) {
      newErrors.confirmPassword = '请确认新密码';
    } else if (passwordData.newPassword !== passwordData.confirmPassword) {
      newErrors.confirmPassword = '两次输入的密码不一致';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateProfileForm()) {
      return;
    }
    
    setLoading(true);
    
    try {
      // 先更新用户信息
      await userService.updateProfile(formData);
      
      // 如果有头像文件，上传头像
      if (avatarFile) {
        const formDataUpload = new FormData();
        formDataUpload.append('avatar', avatarFile);
        
        const response = await userService.uploadAvatar(formDataUpload);
        updateUser({ avatar: response.data.avatar });
      } else {
        updateUser(formData);
      }
      
      // 清除头像文件
      setAvatarFile(null);
    } catch (error) {
      console.error('更新个人资料失败:', error);
      setErrors({
        submit: error.response?.data?.message || '更新个人资料失败'
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    
    if (!validatePasswordForm()) {
      return;
    }
    
    setPasswordLoading(true);
    
    try {
      await userService.changePassword({
        currentPassword: passwordData.currentPassword,
        newPassword: passwordData.newPassword
      });
      
      // 清空密码表单
      setPasswordData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });
      
      setErrors({});
      alert('密码修改成功');
    } catch (error) {
      console.error('修改密码失败:', error);
      setErrors({
        password: error.response?.data?.message || '修改密码失败'
      });
    } finally {
      setPasswordLoading(false);
    }
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        个人资料
      </Typography>
      
      <Grid container spacing={4}>
        {/* 个人资料表单 */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              基本信息
            </Typography>
            
            {errors.submit && (
              <Box sx={{ color: 'error.main', mb: 2 }}>
                {errors.submit}
              </Box>
            )}
            
            <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mb: 3 }}>
              <Avatar
                src={previewImage}
                alt={user?.username}
                sx={{ width: 120, height: 120, mb: 2 }}
              >
                {user?.username?.charAt(0).toUpperCase()}
              </Avatar>
              
              <IconButton
                color="primary"
                aria-label="upload picture"
                component="label"
              >
                <input
                  hidden
                  accept="image/*"
                  type="file"
                  onChange={handleAvatarChange}
                />
                <PhotoCameraIcon />
              </IconButton>
              
              {errors.avatar && (
                <Box sx={{ color: 'error.main', mt: 1 }}>
                  {errors.avatar}
                </Box>
              )}
            </Box>
            
            <Box component="form" onSubmit={handleProfileSubmit}>
              <TextField
                fullWidth
                margin="normal"
                id="username"
                label="用户名"
                name="username"
                autoComplete="username"
                value={formData.username}
                onChange={handleInputChange}
                error={!!errors.username}
                helperText={errors.username}
                disabled={loading}
              />
              <TextField
                fullWidth
                margin="normal"
                id="email"
                label="邮箱地址"
                name="email"
                autoComplete="email"
                value={formData.email}
                onChange={handleInputChange}
                error={!!errors.email}
                helperText={errors.email}
                disabled={loading}
              />
              <Button
                type="submit"
                fullWidth
                variant="contained"
                startIcon={loading ? <CircularProgress size={20} /> : <SaveIcon />}
                sx={{ mt: 2 }}
                disabled={loading}
              >
                保存信息
              </Button>
            </Box>
          </Paper>
        </Grid>
        
        {/* 修改密码表单 */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              修改密码
            </Typography>
            
            {errors.password && (
              <Box sx={{ color: 'error.main', mb: 2 }}>
                {errors.password}
              </Box>
            )}
            
            <Box component="form" onSubmit={handlePasswordSubmit}>
              <TextField
                fullWidth
                margin="normal"
                id="currentPassword"
                label="当前密码"
                name="currentPassword"
                type="password"
                autoComplete="current-password"
                value={passwordData.currentPassword}
                onChange={handlePasswordInputChange}
                error={!!errors.currentPassword}
                helperText={errors.currentPassword}
                disabled={passwordLoading}
              />
              <TextField
                fullWidth
                margin="normal"
                id="newPassword"
                label="新密码"
                name="newPassword"
                type="password"
                autoComplete="new-password"
                value={passwordData.newPassword}
                onChange={handlePasswordInputChange}
                error={!!errors.newPassword}
                helperText={errors.newPassword}
                disabled={passwordLoading}
              />
              <TextField
                fullWidth
                margin="normal"
                id="confirmPassword"
                label="确认新密码"
                name="confirmPassword"
                type="password"
                value={passwordData.confirmPassword}
                onChange={handlePasswordInputChange}
                error={!!errors.confirmPassword}
                helperText={errors.confirmPassword}
                disabled={passwordLoading}
              />
              <Button
                type="submit"
                fullWidth
                variant="contained"
                startIcon={passwordLoading ? <CircularProgress size={20} /> : <SaveIcon />}
                sx={{ mt: 2 }}
                disabled={passwordLoading}
              >
                修改密码
              </Button>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Profile;