import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  Container,
  Grid,
  Paper,
  Typography,
  Box,
  Card,
  CardContent,
  CardActions,
  Button,
  TextField,
  InputAdornment,
  IconButton,
  Fab,
  Pagination,
  Menu,
  MenuItem,
  Chip,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import {
  Add as AddIcon,
  Search as SearchIcon,
  MoreVert as MoreVertIcon,
  Edit as EditIcon,
  Visibility as ViewIcon,
  Delete as DeleteIcon,
  Share as ShareIcon,
  FilterList as FilterIcon
} from '@mui/icons-material';
import { useAuth } from '../../contexts/AuthContext';
import documentService from '../../services/documentService';
import DocumentCreateDialog from '../../components/documents/DocumentCreateDialog';
import CollaboratorDialog from '../../components/documents/CollaboratorDialog';

const Documents = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  // 从URL参数获取初始状态
  const action = searchParams.get('action');
  
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all'); // all, owned, shared
  const [type, setType] = useState('all'); // all, text, markdown
  
  // 对话框状态
  const [createDialogOpen, setCreateDialogOpen] = useState(action === 'create');
  const [collaboratorDialogOpen, setCollaboratorDialogOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [documentToDelete, setDocumentToDelete] = useState(null);
  
  // 菜单状态
  const [anchorEl, setAnchorEl] = useState(null);
  const [menuDocumentId, setMenuDocumentId] = useState(null);

  useEffect(() => {
    fetchDocuments();
  }, [page, search, filter, type]);

  const fetchDocuments = async () => {
    setLoading(true);
    try {
      const params = {
        page,
        limit: 9,
        search: search || undefined,
        sortBy: 'updatedAt',
        sortOrder: 'desc'
      };

      // 应用过滤器
      if (filter === 'owned') {
        // 在实际应用中，这应该在后端处理
        params.owned = true;
      } else if (filter === 'shared') {
        params.shared = true;
      }

      // 应用类型过滤器
      if (type !== 'all') {
        params.type = type;
      }

      const response = await documentService.getDocuments(params);
      
      // 如果是"我的文档"过滤器，手动过滤
      let filteredDocuments = response.data.documents;
      if (filter === 'owned') {
        filteredDocuments = filteredDocuments.filter(
          doc => doc.owner._id === user.id
        );
      } else if (filter === 'shared') {
        filteredDocuments = filteredDocuments.filter(
          doc => doc.owner._id !== user.id && 
                doc.collaborators.some(c => c.user._id === user.id)
        );
      }

      setDocuments(filteredDocuments);
      setTotalPages(response.data.totalPages);
    } catch (error) {
      console.error('获取文档列表失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    setSearch(e.target.value);
    setPage(1);
  };

  const handlePageChange = (event, value) => {
    setPage(value);
  };

  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
    setPage(1);
    setFilterMenuAnchor(null);
  };

  const handleTypeChange = (newType) => {
    setType(newType);
    setPage(1);
    setTypeMenuAnchor(null);
  };

  const handleOpenDocument = (id) => {
    navigate(`/editor/${id}`);
  };

  const handleCreateDocument = () => {
    setCreateDialogOpen(true);
  };

  const handleDocumentCreated = () => {
    setCreateDialogOpen(false);
    fetchDocuments();
  };

  const handleMenuClick = (event, documentId) => {
    setAnchorEl(event.currentTarget);
    setMenuDocumentId(documentId);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    setMenuDocumentId(null);
  };

  const handleShareDocument = (document) => {
    setSelectedDocument(document);
    setCollaboratorDialogOpen(true);
    handleMenuClose();
  };

  const handleDeleteClick = (document) => {
    setDocumentToDelete(document);
    setDeleteDialogOpen(true);
    handleMenuClose();
  };

  const handleConfirmDelete = async () => {
    if (!documentToDelete) return;
    
    try {
      await documentService.deleteDocument(documentToDelete._id);
      fetchDocuments();
      setDeleteDialogOpen(false);
      setDocumentToDelete(null);
    } catch (error) {
      console.error('删除文档失败:', error);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) {
      return '今天';
    } else if (diffDays === 2) {
      return '昨天';
    } else if (diffDays <= 7) {
      return `${diffDays - 1} 天前`;
    } else {
      return date.toLocaleDateString('zh-CN');
    }
  };

  const [filterMenuAnchor, setFilterMenuAnchor] = useState(null);
  const [typeMenuAnchor, setTypeMenuAnchor] = useState(null);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="80vh">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        我的文档
      </Typography>
      
      {/* 搜索和过滤栏 */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="搜索文档..."
            value={search}
            onChange={handleSearch}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
          />
          
          <Button
            variant="outlined"
            startIcon={<FilterIcon />}
            onClick={(e) => setFilterMenuAnchor(e.currentTarget)}
          >
            {filter === 'all' ? '所有文档' : filter === 'owned' ? '我的文档' : '共享文档'}
          </Button>
          
          <Menu
            anchorEl={filterMenuAnchor}
            open={Boolean(filterMenuAnchor)}
            onClose={() => setFilterMenuAnchor(null)}
          >
            <MenuItem onClick={() => handleFilterChange('all')}>所有文档</MenuItem>
            <MenuItem onClick={() => handleFilterChange('owned')}>我的文档</MenuItem>
            <MenuItem onClick={() => handleFilterChange('shared')}>共享文档</MenuItem>
          </Menu>
          
          <Button
            variant="outlined"
            onClick={(e) => setTypeMenuAnchor(e.currentTarget)}
          >
            {type === 'all' ? '所有类型' : type === 'text' ? '文本文档' : 'Markdown文档'}
          </Button>
          
          <Menu
            anchorEl={typeMenuAnchor}
            open={Boolean(typeMenuAnchor)}
            onClose={() => setTypeMenuAnchor(null)}
          >
            <MenuItem onClick={() => handleTypeChange('all')}>所有类型</MenuItem>
            <MenuItem onClick={() => handleTypeChange('text')}>文本文档</MenuItem>
            <MenuItem onClick={() => handleTypeChange('markdown')}>Markdown文档</MenuItem>
          </Menu>
        </Box>
      </Paper>
      
      {/* 文档列表 */}
      {documents.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h6" color="text.secondary" gutterBottom>
            没有找到文档
          </Typography>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={handleCreateDocument}
          >
            创建新文档
          </Button>
        </Paper>
      ) : (
        <Grid container spacing={3}>
          {documents.map((document) => (
            <Grid item xs={12} sm={6} md={4} key={document._id}>
              <Card
                className="document-card"
                sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}
              >
                <CardContent sx={{ flexGrow: 1 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <Typography gutterBottom variant="h6" component="h3" sx={{ flex: 1 }}>
                      {document.title}
                    </Typography>
                    <IconButton
                      size="small"
                      onClick={(e) => handleMenuClick(e, document._id)}
                    >
                      <MoreVertIcon />
                    </IconButton>
                  </Box>
                  
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    {document.content ? document.content.substring(0, 100) + '...' : '空文档'}
                  </Typography>
                  
                  <Box sx={{ mb: 1 }}>
                    <Chip 
                      size="small" 
                      label={document.type === 'text' ? '文本' : 'Markdown'}
                      variant="outlined"
                    />
                    
                    {document.owner._id === user.id ? (
                      <Chip 
                        size="small" 
                        label="所有者"
                        color="primary"
                        sx={{ ml: 1 }}
                      />
                    ) : (
                      <Chip 
                        size="small" 
                        label="共享"
                        color="secondary"
                        sx={{ ml: 1 }}
                      />
                    )}
                  </Box>
                  
                  <Typography variant="caption" color="text.secondary" display="block">
                    更新于 {formatDate(document.updatedAt)}
                  </Typography>
                </CardContent>
                <CardActions>
                  <Button
                    size="small"
                    startIcon={<ViewIcon />}
                    onClick={() => handleOpenDocument(document._id)}
                  >
                    打开
                  </Button>
                  {document.owner._id === user.id && (
                    <Button
                      size="small"
                      startIcon={<EditIcon />}
                      onClick={() => handleOpenDocument(document._id)}
                    >
                      编辑
                    </Button>
                  )}
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
      
      {/* 分页 */}
      {totalPages > 1 && (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
          <Pagination
            count={totalPages}
            page={page}
            onChange={handlePageChange}
            color="primary"
          />
        </Box>
      )}
      
      {/* 浮动创建按钮 */}
      <Fab
        color="primary"
        aria-label="add"
        sx={{
          position: 'fixed',
          bottom: 16,
          right: 16,
        }}
        onClick={handleCreateDocument}
      >
        <AddIcon />
      </Fab>
      
      {/* 文档操作菜单 */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={() => {
          const document = documents.find(d => d._id === menuDocumentId);
          handleShareDocument(document);
        }}>
          <ShareIcon sx={{ mr: 1 }} />
          共享
        </MenuItem>
        {documents.find(d => d._id === menuDocumentId)?.owner._id === user.id && (
          <MenuItem onClick={() => {
            const document = documents.find(d => d._id === menuDocumentId);
            handleDeleteClick(document);
          }}>
            <DeleteIcon sx={{ mr: 1 }} />
            删除
          </MenuItem>
        )}
      </Menu>
      
      {/* 创建文档对话框 */}
      <DocumentCreateDialog
        open={createDialogOpen}
        onClose={() => setCreateDialogOpen(false)}
        onDocumentCreated={handleDocumentCreated}
      />
      
      {/* 协作者对话框 */}
      <CollaboratorDialog
        open={collaboratorDialogOpen}
        onClose={() => setCollaboratorDialogOpen(false)}
        document={selectedDocument}
        onCollaboratorsUpdated={fetchDocuments}
      />
      
      {/* 删除确认对话框 */}
      <Dialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
      >
        <DialogTitle>确认删除</DialogTitle>
        <DialogContent>
          <Typography>
            您确定要删除文档 "{documentToDelete?.title}" 吗？此操作无法撤销。
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)}>取消</Button>
          <Button onClick={handleConfirmDelete} color="error">删除</Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default Documents;