import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Container,
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  IconButton,
  Toolbar,
  Chip,
  Avatar,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Divider,
  InputBase,
  Fab,
  Drawer,
  useTheme,
  useMediaQuery,
  CircularProgress,
  Tooltip,
  Menu,
  MenuItem
} from '@mui/material';
import {
  Save as SaveIcon,
  ArrowBack as ArrowBackIcon,
  Share as ShareIcon,
  MoreVert as MoreVertIcon,
  Send as SendIcon,
  Person as PersonIcon,
  Chat as ChatIcon,
  Assignment as TaskIcon,
  Comment as CommentIcon,
  Close as CloseIcon
} from '@mui/icons-material';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { useAuth } from '../../contexts/AuthContext';
import { useSocket } from '../../contexts/SocketContext';
import documentService from '../../services/documentService';
import userService from '../../services/userService';
import CollaboratorDialog from '../../components/documents/CollaboratorDialog';
import CommentDialog from '../../components/editor/CommentDialog';
import TaskDialog from '../../components/editor/TaskDialog';

const DocumentEditor = () => {
  const { id: documentId } = useParams();
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const { user } = useAuth();
  const { socket, connected, joinDocument, leaveDocument, sendDocumentChange, sendCursorUpdate, sendChatMessage } = useSocket();
  
  // 文档状态
  const [document, setDocument] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [version, setVersion] = useState(0);
  
  // 协作状态
  const [activeUsers, setActiveUsers] = useState([]);
  const [cursors, setCursors] = useState({});
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  
  // UI状态
  const [drawerOpen, setDrawerOpen] = useState(!isMobile);
  const [currentTab, setCurrentTab] = useState('users'); // users, chat, comments, tasks
  const [collaboratorDialogOpen, setCollaboratorDialogOpen] = useState(false);
  const [commentDialogOpen, setCommentDialogOpen] = useState(false);
  const [taskDialogOpen, setTaskDialogOpen] = useState(false);
  const [commentPosition, setCommentPosition] = useState(null);
  const [anchorEl, setAnchorEl] = useState(null);
  
  const editorRef = useRef(null);
  const autoSaveTimeoutRef = useRef(null);

  // 加载文档
  useEffect(() => {
    const fetchDocument = async () => {
      try {
        const response = await documentService.getDocument(documentId);
        const doc = response.data.document;
        
        setDocument(doc);
        setTitle(doc.title);
        setContent(doc.content);
        setVersion(0); // 本地版本从0开始
      } catch (error) {
        console.error('加载文档失败:', error);
        navigate('/documents');
      } finally {
        setLoading(false);
      }
    };

    fetchDocument();
  }, [documentId, navigate]);

  // 加入文档房间
  useEffect(() => {
    if (document && socket && connected) {
      joinDocument(documentId);
      
      return () => {
        leaveDocument(documentId);
      };
    }
  }, [document, socket, connected, documentId, joinDocument, leaveDocument]);

  // 监听Socket.IO事件
  useEffect(() => {
    if (!socket) return;

    // 文档加入成功
    const handleDocumentJoined = (data) => {
      console.log('已加入文档房间', data);
      setActiveUsers(data.users);
    };

    // 其他用户加入
    const handleUserJoined = (data) => {
      setActiveUsers(prev => [...prev, data.user]);
    };

    // 其他用户离开
    const handleUserLeft = (data) => {
      setActiveUsers(prev => prev.filter(u => u.id !== data.userId));
      setCursors(prev => {
        const newCursors = { ...prev };
        delete newCursors[data.userId];
        return newCursors;
      });
    };

    // 文档内容变更
    const handleDocumentChanged = (data) => {
      console.log('收到文档变更', data);
      
      // 应用远程变更
      applyRemoteChange(data.operation);
      setVersion(data.version);
    };

    // 光标位置更新
    const handleCursorUpdated = (data) => {
      setCursors(prev => ({
        ...prev,
        [data.userId]: {
          userId: data.userId,
          username: data.username,
          position: data.position,
          color: data.color
        }
      }));
    };

    // 聊天消息
    const handleChatMessage = (message) => {
      setChatMessages(prev => [...prev, message]);
    };

    // 注册事件监听器
    socket.on('document-joined', handleDocumentJoined);
    socket.on('user-joined', handleUserJoined);
    socket.on('user-left', handleUserLeft);
    socket.on('document-changed', handleDocumentChanged);
    socket.on('cursor-updated', handleCursorUpdated);
    socket.on('chat-message', handleChatMessage);

    // 清理函数
    return () => {
      socket.off('document-joined', handleDocumentJoined);
      socket.off('user-joined', handleUserJoined);
      socket.off('user-left', handleUserLeft);
      socket.off('document-changed', handleDocumentChanged);
      socket.off('cursor-updated', handleCursorUpdated);
      socket.off('chat-message', handleChatMessage);
    };
  }, [socket]);

  // 应用远程变更到内容
  const applyRemoteChange = (operation) => {
    // 简化的操作应用逻辑
    // 实际应用中应该使用Operational Transform或CRDT
    const { type, position, text, length } = operation;
    
    setContent(prevContent => {
      if (type === 'insert') {
        return prevContent.slice(0, position) + text + prevContent.slice(position);
      } else if (type === 'delete') {
        return prevContent.slice(0, position) + prevContent.slice(position + length);
      }
      return prevContent;
    });
  };

  // 处理内容变更
  const handleContentChange = (newContent) => {
    setContent(newContent);
    
    // 清除之前的自动保存定时器
    if (autoSaveTimeoutRef.current) {
      clearTimeout(autoSaveTimeoutRef.current);
    }
    
    // 设置自动保存定时器
    autoSaveTimeoutRef.current = setTimeout(() => {
      saveDocument(newContent);
    }, 2000); // 2秒后自动保存
    
    // 发送变更到Socket.IO
    if (socket && connected) {
      // 简化的操作生成逻辑
      // 实际应用中应该使用更复杂的差异算法
      const operation = generateContentOperation(content, newContent);
      if (operation) {
        sendDocumentChange(documentId, operation, version);
        setVersion(prev => prev + 1);
      }
    }
  };

  // 生成内容操作
  const generateContentOperation = (oldContent, newContent) => {
    // 简化的差异算法
    // 实际应用中应该使用专业的差异算法
    if (oldContent === newContent) return null;
    
    // 这里简化处理，假设只有插入操作
    const minLength = Math.min(oldContent.length, newContent.length);
    let firstDiff = 0;
    
    while (firstDiff < minLength && oldContent[firstDiff] === newContent[firstDiff]) {
      firstDiff++;
    }
    
    if (firstDiff < newContent.length) {
      return {
        type: 'insert',
        position: firstDiff,
        text: newContent.substring(firstDiff)
      };
    }
    
    return null;
  };

  // 保存文档
  const saveDocument = async (documentContent = content) => {
    if (!document) return;
    
    setSaving(true);
    try {
      await documentService.updateDocument(documentId, {
        title,
        content: documentContent
      });
    } catch (error) {
      console.error('保存文档失败:', error);
    } finally {
      setSaving(false);
    }
  };

  // 处理标题变更
  const handleTitleChange = (e) => {
    const newTitle = e.target.value;
    setTitle(newTitle);
    
    // 自动保存标题
    if (document) {
      saveDocument(content);
    }
  };

  // 发送聊天消息
  const handleSendChatMessage = () => {
    if (!chatInput.trim()) return;
    
    sendChatMessage(documentId, chatInput);
    setChatInput('');
  };

  // 处理菜单点击
  const handleMenuClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  // 处理添加评论
  const handleAddComment = (position) => {
    setCommentPosition(position);
    setCommentDialogOpen(true);
    handleMenuClose();
  };

  // 处理添加任务
  const handleAddTask = () => {
    setTaskDialogOpen(true);
    handleMenuClose();
  };

  // 处理共享文档
  const handleShareDocument = () => {
    setCollaboratorDialogOpen(true);
    handleMenuClose();
  };

  // 侧边栏内容
  const renderSidebarContent = () => {
    switch (currentTab) {
      case 'users':
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              协作者 ({activeUsers.length})
            </Typography>
            <List>
              {activeUsers.map((activeUser) => (
                <ListItem key={activeUser.id}>
                  <ListItemAvatar>
                    <Avatar
                      src={activeUser.avatar}
                      alt={activeUser.username}
                      sx={{ bgcolor: activeUser.color }}
                    >
                      {activeUser.username.charAt(0).toUpperCase()}
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={activeUser.username}
                    secondary={activeUser.id === user.id ? '你' : '协作者'}
                  />
                </ListItem>
              ))}
            </List>
          </Box>
        );
        
      case 'chat':
        return (
          <Box className="chat-container">
            <Typography variant="h6" gutterBottom>
              聊天
            </Typography>
            <Box className="chat-messages" sx={{ flexGrow: 1, overflowY: 'auto', mb: 2 }}>
              {chatMessages.length === 0 ? (
                <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 2 }}>
                  暂无聊天消息
                </Typography>
              ) : (
                chatMessages.map((message) => (
                  <Box
                    key={message.id}
                    sx={{
                      mb: 1,
                      display: 'flex',
                      flexDirection: message.userId === user.id ? 'row-reverse' : 'row'
                    }}
                  >
                    <Avatar
                      src={message.avatar}
                      alt={message.username}
                      sx={{ width: 32, height: 32, mx: 1 }}
                    >
                      {message.username.charAt(0).toUpperCase()}
                    </Avatar>
                    <Paper
                      sx={{
                        p: 1,
                        maxWidth: '70%',
                        bgcolor: message.userId === user.id ? 'primary.main' : 'grey.200',
                        color: message.userId === user.id ? 'white' : 'text.primary'
                      }}
                    >
                      <Typography variant="body2">
                        {message.message}
                      </Typography>
                    </Paper>
                  </Box>
                ))
              )}
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <InputBase
                fullWidth
                placeholder="输入消息..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendChatMessage()}
                sx={{ mr: 1, p: 1, border: '1px solid #ccc', borderRadius: 1 }}
              />
              <IconButton onClick={handleSendChatMessage} color="primary">
                <SendIcon />
              </IconButton>
            </Box>
          </Box>
        );
        
      case 'comments':
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              评论
            </Typography>
            {document?.comments?.length === 0 ? (
              <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 2 }}>
                暂无评论
              </Typography>
            ) : (
              <List>
                {document?.comments?.map((comment) => (
                  <ListItem key={comment._id}>
                    <ListItemAvatar>
                      <Avatar src={comment.author.avatar}>
                        {comment.author.username.charAt(0).toUpperCase()}
                      </Avatar>
                    </ListItemAvatar>
                    <ListItemText
                      primary={comment.content}
                      secondary={`${comment.author.username} · ${new Date(comment.createdAt).toLocaleString()}`}
                    />
                  </ListItem>
                ))}
              </List>
            )}
          </Box>
        );
        
      case 'tasks':
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              任务
            </Typography>
            {document?.tasks?.length === 0 ? (
              <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 2 }}>
                暂无任务
              </Typography>
            ) : (
              <List>
                {document?.tasks?.map((task) => (
                  <ListItem key={task._id}>
                    <ListItemText
                      primary={task.title}
                      secondary={
                        <Box>
                          <Chip
                            size="small"
                            label={task.status === 'todo' ? '待办' : task.status === 'in-progress' ? '进行中' : '已完成'}
                            color={task.status === 'completed' ? 'success' : 'default'}
                          />
                          {task.dueDate && (
                            <Typography variant="caption" display="block">
                              截止日期: {new Date(task.dueDate).toLocaleDateString()}
                            </Typography>
                          )}
                        </Box>
                      }
                    />
                  </ListItem>
                ))}
              </List>
            )}
          </Box>
        );
        
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="80vh">
        <CircularProgress />
      </Box>
    );
  }

  if (!document) {
    return (
      <Container maxWidth="lg">
        <Typography variant="h5">文档不存在</Typography>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 2, mb: 2 }}>
      <Box className="editor-container">
        {/* 编辑器头部 */}
        <Paper className="editor-header" sx={{ display: 'flex', alignItems: 'center', p: 1 }}>
          <IconButton onClick={() => navigate('/documents')}>
            <ArrowBackIcon />
          </IconButton>
          
          <TextField
            variant="outlined"
            value={title}
            onChange={handleTitleChange}
            fullWidth
            sx={{ mx: 1 }}
          />
          
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            {saving ? (
              <CircularProgress size={24} sx={{ mr: 1 }} />
            ) : (
              <SaveIcon color="action" sx={{ mr: 1 }} />
            )}
            
            <IconButton onClick={handleShareDocument}>
              <ShareIcon />
            </IconButton>
            
            <IconButton onClick={handleMenuClick}>
              <MoreVertIcon />
            </IconButton>
            
            <Menu
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleMenuClose}
            >
              <MenuItem onClick={handleAddComment}>
                <CommentIcon sx={{ mr: 1 }} />
                添加评论
              </MenuItem>
              <MenuItem onClick={handleAddTask}>
                <TaskIcon sx={{ mr: 1 }} />
                添加任务
              </MenuItem>
            </Menu>
          </Box>
        </Paper>
        
        {/* 编辑器内容区 */}
        <Box className="editor-content">
          <Box className="editor-main" sx={{ flex: 1, p: 2 }}>
            <ReactQuill
              value={content}
              onChange={handleContentChange}
              theme="snow"
              placeholder="开始编写文档..."
              modules={{
                toolbar: [
                  [{ 'header': [1, 2, 3, false] }],
                  ['bold', 'italic', 'underline', 'strike'],
                  [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                  ['blockquote', 'code-block'],
                  ['link', 'image'],
                  ['clean']
                ]
              }}
            />
          </Box>
          
          {/* 侧边栏 */}
          {!isMobile && (
            <Drawer
              variant="persistent"
              anchor="right"
              open={drawerOpen}
              sx={{
                width: 300,
                flexShrink: 0,
                '& .MuiDrawer-paper': {
                  width: 300,
                  boxSizing: 'border-box',
                  p: 2,
                },
              }}
            >
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">协作面板</Typography>
                <IconButton onClick={() => setDrawerOpen(false)}>
                  <CloseIcon />
                </IconButton>
              </Box>
              
              <Toolbar variant="dense" sx={{ mb: 2 }}>
                <Button
                  size="small"
                  onClick={() => setCurrentTab('users')}
                  variant={currentTab === 'users' ? 'contained' : 'text'}
                  sx={{ mr: 1 }}
                >
                  <PersonIcon fontSize="small" />
                </Button>
                <Button
                  size="small"
                  onClick={() => setCurrentTab('chat')}
                  variant={currentTab === 'chat' ? 'contained' : 'text'}
                  sx={{ mr: 1 }}
                >
                  <ChatIcon fontSize="small" />
                </Button>
                <Button
                  size="small"
                  onClick={() => setCurrentTab('comments')}
                  variant={currentTab === 'comments' ? 'contained' : 'text'}
                  sx={{ mr: 1 }}
                >
                  <CommentIcon fontSize="small" />
                </Button>
                <Button
                  size="small"
                  onClick={() => setCurrentTab('tasks')}
                  variant={currentTab === 'tasks' ? 'contained' : 'text'}
                >
                  <TaskIcon fontSize="small" />
                </Button>
              </Toolbar>
              
              {renderSidebarContent()}
            </Drawer>
          )}
        </Box>
      </Box>
      
      {/* 移动端浮动按钮 */}
      {isMobile && (
        <Fab
          color="primary"
          aria-label="menu"
          sx={{
            position: 'fixed',
            bottom: 16,
            right: 16,
          }}
          onClick={() => setDrawerOpen(true)}
        >
          <ChatIcon />
        </Fab>
      )}
      
      {/* 移动端抽屉 */}
      <Drawer
        anchor="right"
        open={isMobile && drawerOpen}
        onClose={() => setDrawerOpen(false)}
      >
        <Box sx={{ width: 300, p: 2 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6">协作面板</Typography>
            <IconButton onClick={() => setDrawerOpen(false)}>
              <CloseIcon />
            </IconButton>
          </Box>
          
          <Toolbar variant="dense" sx={{ mb: 2 }}>
            <Button
              size="small"
              onClick={() => setCurrentTab('users')}
              variant={currentTab === 'users' ? 'contained' : 'text'}
              sx={{ mr: 1 }}
            >
              <PersonIcon fontSize="small" />
            </Button>
            <Button
              size="small"
              onClick={() => setCurrentTab('chat')}
              variant={currentTab === 'chat' ? 'contained' : 'text'}
              sx={{ mr: 1 }}
            >
              <ChatIcon fontSize="small" />
            </Button>
            <Button
              size="small"
              onClick={() => setCurrentTab('comments')}
              variant={currentTab === 'comments' ? 'contained' : 'text'}
              sx={{ mr: 1 }}
            >
              <CommentIcon fontSize="small" />
            </Button>
            <Button
              size="small"
              onClick={() => setCurrentTab('tasks')}
              variant={currentTab === 'tasks' ? 'contained' : 'text'}
            >
              <TaskIcon fontSize="small" />
            </Button>
          </Toolbar>
          
          {renderSidebarContent()}
        </Box>
      </Drawer>
      
      {/* 协作者对话框 */}
      <CollaboratorDialog
        open={collaboratorDialogOpen}
        onClose={() => setCollaboratorDialogOpen(false)}
        document={document}
        onCollaboratorsUpdated={() => {
          // 重新加载文档以获取最新的协作者列表
          documentService.getDocument(documentId).then(response => {
            setDocument(response.data.document);
          });
        }}
      />
      
      {/* 评论对话框 */}
      <CommentDialog
        open={commentDialogOpen}
        onClose={() => setCommentDialogOpen(false)}
        documentId={documentId}
        position={commentPosition}
        onCommentAdded={() => {
          // 重新加载文档以获取最新的评论列表
          documentService.getDocument(documentId).then(response => {
            setDocument(response.data.document);
          });
        }}
      />
      
      {/* 任务对话框 */}
      <TaskDialog
        open={taskDialogOpen}
        onClose={() => setTaskDialogOpen(false)}
        documentId={documentId}
        onTaskAdded={() => {
          // 重新加载文档以获取最新的任务列表
          documentService.getDocument(documentId).then(response => {
            setDocument(response.data.document);
          });
        }}
      />
    </Container>
  );
};

export default DocumentEditor;