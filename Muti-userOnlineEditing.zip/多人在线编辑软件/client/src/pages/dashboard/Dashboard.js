import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Grid,
  Paper,
  Typography,
  Box,
  Card,
  CardContent,
  CardActions,
  Button,
  Fab,
  CircularProgress
} from '@mui/material';
import {
  Add as AddIcon,
  FileCopy as FileIcon,
  Visibility as ViewIcon,
  Edit as EditIcon
} from '@mui/icons-material';
import { useAuth } from '../../contexts/AuthContext';
import documentService from '../../services/documentService';

const Dashboard = () => {
  const [recentDocuments, setRecentDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    fetchRecentDocuments();
  }, []);

  const fetchRecentDocuments = async () => {
    try {
      const response = await documentService.getDocuments({
        limit: 6,
        sortBy: 'updatedAt',
        sortOrder: 'desc'
      });
      setRecentDocuments(response.data.documents);
    } catch (error) {
      console.error('获取最近文档失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateDocument = () => {
    navigate('/documents?action=create');
  };

  const handleOpenDocument = (id) => {
    navigate(`/editor/${id}`);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) {
      return '今天';
    } else if (diffDays === 2) {
      return '昨天';
    } else if (diffDays <= 7) {
      return `${diffDays - 1} 天前`;
    } else {
      return date.toLocaleDateString('zh-CN');
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="80vh">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        欢迎回来, {user?.username}!
      </Typography>
      
      <Grid container spacing={3}>
        {/* 最近文档 */}
        <Grid item xs={12}>
          <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column' }}>
            <Typography variant="h6" component="h2" gutterBottom>
              最近文档
            </Typography>
            
            {recentDocuments.length === 0 ? (
              <Box sx={{ textAlign: 'center', py: 4 }}>
                <Typography variant="body1" color="text.secondary" gutterBottom>
                  您还没有任何文档
                </Typography>
                <Button
                  variant="contained"
                  startIcon={<AddIcon />}
                  onClick={handleCreateDocument}
                >
                  创建第一个文档
                </Button>
              </Box>
            ) : (
              <Grid container spacing={2}>
                {recentDocuments.map((document) => (
                  <Grid item xs={12} sm={6} md={4} key={document._id}>
                    <Card
                      className="document-card"
                      sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}
                    >
                      <CardContent sx={{ flexGrow: 1 }}>
                        <Typography gutterBottom variant="h6" component="h3">
                          {document.title}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {document.content ? document.content.substring(0, 100) + '...' : '空文档'}
                        </Typography>
                        <Box sx={{ mt: 1, display: 'flex', justifyContent: 'space-between' }}>
                          <Typography variant="caption" color="text.secondary">
                            更新于 {formatDate(document.updatedAt)}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {document.type === 'text' ? '文本文档' : 'Markdown文档'}
                          </Typography>
                        </Box>
                      </CardContent>
                      <CardActions>
                        <Button
                          size="small"
                          startIcon={<ViewIcon />}
                          onClick={() => handleOpenDocument(document._id)}
                        >
                          打开
                        </Button>
                        {document.owner._id === user?.id && (
                          <Button
                            size="small"
                            startIcon={<EditIcon />}
                            onClick={() => handleOpenDocument(document._id)}
                          >
                            编辑
                          </Button>
                        )}
                      </CardActions>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            )}
          </Paper>
        </Grid>
      </Grid>
      
      {/* 浮动创建按钮 */}
      <Fab
        color="primary"
        aria-label="add"
        sx={{
          position: 'fixed',
          bottom: 16,
          right: 16,
        }}
        onClick={handleCreateDocument}
      >
        <AddIcon />
      </Fab>
    </Container>
  );
};

export default Dashboard;