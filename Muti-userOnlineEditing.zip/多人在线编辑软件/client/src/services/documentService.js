import { api } from './authService';

const documentService = {
  // 获取所有文档
  getDocuments: (params) => {
    return api.get('/documents', { params });
  },

  // 获取单个文档
  getDocument: (id) => {
    return api.get(`/documents/${id}`);
  },

  // 创建新文档
  createDocument: (documentData) => {
    return api.post('/documents', documentData);
  },

  // 更新文档
  updateDocument: (id, documentData) => {
    return api.put(`/documents/${id}`, documentData);
  },

  // 删除文档
  deleteDocument: (id) => {
    return api.delete(`/documents/${id}`);
  },

  // 添加协作者
  addCollaborator: (id, collaboratorData) => {
    return api.post(`/documents/${id}/collaborators`, collaboratorData);
  },

  // 更新协作者权限
  updateCollaboratorPermission: (id, collaboratorId, permission) => {
    return api.put(`/documents/${id}/collaborators/${collaboratorId}`, { permission });
  },

  // 移除协作者
  removeCollaborator: (id, collaboratorId) => {
    return api.delete(`/documents/${id}/collaborators/${collaboratorId}`);
  },

  // 添加评论
  addComment: (id, commentData) => {
    return api.post(`/documents/${id}/comments`, commentData);
  },

  // 添加任务
  addTask: (id, taskData) => {
    return api.post(`/documents/${id}/tasks`, taskData);
  },

  // 更新任务状态
  updateTaskStatus: (id, taskId, status) => {
    return api.put(`/documents/${id}/tasks/${taskId}`, { status });
  }
};

export default documentService;