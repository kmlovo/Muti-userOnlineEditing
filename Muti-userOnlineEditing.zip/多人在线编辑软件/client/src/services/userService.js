import { api } from './authService';

const userService = {
  // 获取所有用户
  getUsers: (params) => {
    return api.get('/users', { params });
  },

  // 获取单个用户
  getUser: (id) => {
    return api.get(`/users/${id}`);
  },

  // 更新个人资料
  updateProfile: (userData) => {
    return api.put('/users/profile', userData);
  },

  // 更改密码
  changePassword: (passwordData) => {
    return api.put('/users/password', passwordData);
  },

  // 上传头像
  uploadAvatar: (formData) => {
    return api.post('/users/avatar', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
  },

  // 更新用户角色
  updateUserRole: (id, role) => {
    return api.put(`/users/${id}/role`, { role });
  },

  // 更新用户状态
  updateUserStatus: (id, isActive) => {
    return api.put(`/users/${id}/status`, { isActive });
  }
};

export default userService;