import axios from 'axios';

// 设置基础URL
const API_URL = process.env.REACT_APP_API_URL || '/api';

// 创建axios实例
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// 添加请求拦截器，在每个请求中添加token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// 添加响应拦截器，处理通用错误
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    // 如果token过期，清除本地存储并重定向到登录页
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

const authService = {
  // 用户注册
  register: (userData) => {
    return api.post('/auth/register', userData);
  },

  // 用户登录
  login: (credentials) => {
    return api.post('/auth/login', credentials);
  },

  // 获取当前用户信息
  getCurrentUser: () => {
    return api.get('/auth/me');
  },

  // 忘记密码
  forgotPassword: (email) => {
    return api.post('/auth/forgot-password', { email });
  },

  // 重置密码
  resetPassword: (resetToken, newPassword) => {
    return api.post('/auth/reset-password', { resetToken, newPassword });
  }
};

export { authService, api };