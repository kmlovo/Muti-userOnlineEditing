import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  IconButton,
  Menu,
  MenuItem,
  Badge,
  Avatar,
  Divider,
  ListItemIcon,
  ListItemText,
  Tooltip
} from '@mui/material';
import {
  AccountCircle,
  Notifications,
  FileCopy,
  ExitToApp,
  Settings,
  Home
} from '@mui/icons-material';
import { useAuth } from '../../contexts/AuthContext';
import { useSocket } from '../../contexts/SocketContext';
import notificationService from '../../services/notificationService';
import logo from '../../assets/logo.png';

const Navbar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout, isAuthenticated } = useAuth();
  const { connected } = useSocket();
  const [anchorEl, setAnchorEl] = useState(null);
  const [notificationAnchorEl, setNotificationAnchorEl] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);

  const isMenuOpen = Boolean(anchorEl);
  const isNotificationMenuOpen = Boolean(notificationAnchorEl);

  // 获取未读通知数量
  useEffect(() => {
    if (isAuthenticated) {
      const fetchUnreadCount = async () => {
        try {
          const response = await notificationService.getUnreadCount();
          setUnreadCount(response.data.unreadCount);
        } catch (error) {
          console.error('获取未读通知数量失败:', error);
        }
      };

      fetchUnreadCount();

      // 定时刷新未读通知数量
      const interval = setInterval(fetchUnreadCount, 30000); // 每30秒刷新一次
      return () => clearInterval(interval);
    }
  }, [isAuthenticated]);

  // 获取通知列表
  const handleNotificationMenuOpen = async (event) => {
    setNotificationAnchorEl(event.currentTarget);

    try {
      const response = await notificationService.getNotifications({ limit: 10 });
      setNotifications(response.data.notifications);
    } catch (error) {
      console.error('获取通知列表失败:', error);
    }
  };

  const handleProfileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleNotificationMenuClose = () => {
    setNotificationAnchorEl(null);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
    handleMenuClose();
  };

  const navigateTo = (path) => {
    navigate(path);
    handleMenuClose();
  };

  const handleNotificationClick = async (notificationId) => {
    try {
      await notificationService.markAsRead(notificationId);
      
      // 更新通知列表和未读数量
      setNotifications(notifications.map(
        n => n._id === notificationId ? { ...n, isRead: true } : n
      ));
      
      setUnreadCount(Math.max(0, unreadCount - 1));
      
      // 如果通知关联了文档，导航到该文档
      const notification = notifications.find(n => n._id === notificationId);
      if (notification.relatedDocument) {
        navigate(`/editor/${notification.relatedDocument._id}`);
        handleNotificationMenuClose();
      }
    } catch (error) {
      console.error('标记通知为已读失败:', error);
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      await notificationService.markAllAsRead();
      
      // 更新通知列表和未读数量
      setNotifications(notifications.map(n => ({ ...n, isRead: true })));
      setUnreadCount(0);
    } catch (error) {
      console.error('标记所有通知为已读失败:', error);
    }
  };

  const menuId = 'primary-search-account-menu';
  const notificationMenuId = 'primary-search-notification-menu';

  return (
    <AppBar position="fixed">
      <Toolbar>
        <Typography
          variant="h6"
          noWrap
          component="div"
          sx={{ mr: 2, display: { xs: 'none', md: 'flex' }, cursor: 'pointer' }}
          onClick={() => navigate('/')}
        >
          多人在线编辑
        </Typography>

        <Box sx={{ flexGrow: 1 }} />

        {isAuthenticated ? (
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Tooltip title={connected ? "已连接" : "连接中"} arrow>
              <Box
                sx={{
                  width: 10,
                  height: 10,
                  borderRadius: '50%',
                  backgroundColor: connected ? '#4caf50' : '#ff9800',
                  mr: 1
                }}
              />
            </Tooltip>

            <IconButton
              size="large"
              aria-label="show notifications"
              aria-controls={notificationMenuId}
              aria-haspopup="true"
              onClick={handleNotificationMenuOpen}
              color="inherit"
            >
              <Badge badgeContent={unreadCount} color="error">
                <Notifications />
              </Badge>
            </IconButton>

            <IconButton
              size="large"
              edge="end"
              aria-label="account of current user"
              aria-controls={menuId}
              aria-haspopup="true"
              onClick={handleProfileMenuOpen}
              color="inherit"
            >
              <Avatar
                src={user?.avatar}
                alt={user?.username}
                sx={{ width: 32, height: 32 }}
              >
                {user?.username?.charAt(0).toUpperCase()}
              </Avatar>
            </IconButton>
          </Box>
        ) : (
          <Box>
            <Button color="inherit" onClick={() => navigate('/login')}>
              登录
            </Button>
            <Button color="inherit" onClick={() => navigate('/register')}>
              注册
            </Button>
          </Box>
        )}
      </Toolbar>

      {/* 用户菜单 */}
      <Menu
        anchorEl={anchorEl}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
        keepMounted
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
        open={isMenuOpen}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={() => navigateTo('/')}>
          <ListItemIcon>
            <Home fontSize="small" />
          </ListItemIcon>
          <ListItemText>首页</ListItemText>
        </MenuItem>
        
        <MenuItem onClick={() => navigateTo('/documents')}>
          <ListItemIcon>
            <FileCopy fontSize="small" />
          </ListItemIcon>
          <ListItemText>我的文档</ListItemText>
        </MenuItem>
        
        <Divider />
        
        <MenuItem onClick={() => navigateTo('/profile')}>
          <ListItemIcon>
            <AccountCircle fontSize="small" />
          </ListItemIcon>
          <ListItemText>个人资料</ListItemText>
        </MenuItem>
        
        <MenuItem onClick={handleLogout}>
          <ListItemIcon>
            <ExitToApp fontSize="small" />
          </ListItemIcon>
          <ListItemText>退出登录</ListItemText>
        </MenuItem>
      </Menu>

      {/* 通知菜单 */}
      <Menu
        anchorEl={notificationAnchorEl}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        keepMounted
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
        open={isNotificationMenuOpen}
        onClose={handleNotificationMenuClose}
        PaperProps={{
          style: {
            width: 320,
            maxHeight: 400,
          },
        }}
      >
        <Box sx={{ p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6">通知</Typography>
          {unreadCount > 0 && (
            <Button size="small" onClick={handleMarkAllAsRead}>
              全部已读
            </Button>
          )}
        </Box>
        
        <Divider />
        
        {notifications.length === 0 ? (
          <MenuItem>
            <Typography variant="body2" color="text.secondary">
              暂无通知
            </Typography>
          </MenuItem>
        ) : (
          notifications.map((notification) => (
            <MenuItem
              key={notification._id}
              onClick={() => handleNotificationClick(notification._id)}
              sx={{ 
                py: 1.5,
                px: 2,
                flexDirection: 'column',
                alignItems: 'flex-start',
                backgroundColor: notification.isRead ? 'transparent' : 'rgba(25, 118, 210, 0.08)'
              }}
            >
              <Typography variant="subtitle2" sx={{ fontWeight: notification.isRead ? 'normal' : 'bold' }}>
                {notification.title}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
                {notification.message}
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5 }}>
                {new Date(notification.createdAt).toLocaleString('zh-CN', {
                  month: 'short',
                  day: 'numeric',
                  hour: 'numeric',
                  minute: '2-digit'
                })}
              </Typography>
            </MenuItem>
          ))
        )}
      </Menu>
    </AppBar>
  );
};

export default Navbar;