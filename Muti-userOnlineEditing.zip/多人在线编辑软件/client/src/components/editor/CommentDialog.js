import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Box,
  Typography,
  CircularProgress
} from '@mui/material';
import documentService from '../../services/documentService';

const CommentDialog = ({ open, onClose, documentId, position, onCommentAdded }) => {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setContent(e.target.value);
    
    // 清除错误
    if (errors.content) {
      setErrors({
        ...errors,
        content: ''
      });
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!content.trim()) {
      newErrors.content = '评论内容不能为空';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setLoading(true);
    
    try {
      await documentService.addComment(documentId, {
        content: content.trim(),
        position: position || { line: 0, column: 0 }
      });
      
      // 重置表单
      setContent('');
      
      // 通知父组件
      onCommentAdded && onCommentAdded();
      handleClose();
    } catch (error) {
      console.error('添加评论失败:', error);
      setErrors({
        submit: error.response?.data?.message || '添加评论失败'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setContent('');
    setErrors({});
    onClose();
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle>添加评论</DialogTitle>
      
      <DialogContent>
        {position && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="body2" color="text.secondary">
              位置: 行 {position.line}, 列 {position.column}
            </Typography>
          </Box>
        )}
        
        {errors.submit && (
          <Box sx={{ color: 'error.main', mb: 2 }}>
            {errors.submit}
          </Box>
        )}
        
        <TextField
          autoFocus
          margin="dense"
          id="content"
          name="content"
          label="评论内容"
          multiline
          rows={4}
          fullWidth
          variant="outlined"
          value={content}
          onChange={handleChange}
          error={!!errors.content}
          helperText={errors.content}
          disabled={loading}
        />
      </DialogContent>
      
      <DialogActions>
        <Button onClick={handleClose} disabled={loading}>
          取消
        </Button>
        <Button
          onClick={handleSubmit}
          variant="contained"
          disabled={loading}
          startIcon={loading ? <CircularProgress size={20} /> : null}
        >
          添加评论
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CommentDialog;