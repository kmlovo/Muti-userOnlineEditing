import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Box,
  Typography,
  CircularProgress
} from '@mui/material';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { zhCN } from '@mui/x-date-pickers/locales';
import documentService from '../../services/documentService';
import userService from '../../services/userService';

const TaskDialog = ({ open, onClose, documentId, onTaskAdded }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    assignedTo: '',
    dueDate: null
  });
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (open) {
      fetchUsers();
    }
  }, [open]);

  const fetchUsers = async () => {
    try {
      const response = await userService.getUsers({ limit: 50 });
      setUsers(response.data.users);
    } catch (error) {
      console.error('获取用户列表失败:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // 清除该字段的错误
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  const handleDateChange = (newDate) => {
    setFormData({
      ...formData,
      dueDate: newDate
    });
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.title.trim()) {
      newErrors.title = '任务标题不能为空';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setLoading(true);
    
    try {
      await documentService.addTask(documentId, {
        title: formData.title.trim(),
        description: formData.description.trim(),
        assignedTo: formData.assignedTo || null,
        dueDate: formData.dueDate ? formData.dueDate.toISOString() : null
      });
      
      // 重置表单
      setFormData({
        title: '',
        description: '',
        assignedTo: '',
        dueDate: null
      });
      
      // 通知父组件
      onTaskAdded && onTaskAdded();
      handleClose();
    } catch (error) {
      console.error('添加任务失败:', error);
      setErrors({
        submit: error.response?.data?.message || '添加任务失败'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setFormData({
      title: '',
      description: '',
      assignedTo: '',
      dueDate: null
    });
    setErrors({});
    onClose();
  };

  return (
    <LocalizationProvider
      dateAdapter={AdapterDateFns}
      adapterLocale={zhCN.components.MuiLocalizationProvider.defaultProps.localeText}
    >
      <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
        <DialogTitle>添加任务</DialogTitle>
        
        <DialogContent>
          {errors.submit && (
            <Box sx={{ color: 'error.main', mb: 2 }}>
              {errors.submit}
            </Box>
          )}
          
          <Box component="form" onSubmit={handleSubmit}>
            <TextField
              autoFocus
              margin="dense"
              id="title"
              name="title"
              label="任务标题"
              type="text"
              fullWidth
              variant="outlined"
              value={formData.title}
              onChange={handleChange}
              error={!!errors.title}
              helperText={errors.title}
              disabled={loading}
              sx={{ mb: 2 }}
            />
            
            <TextField
              margin="dense"
              id="description"
              name="description"
              label="任务描述"
              multiline
              rows={3}
              fullWidth
              variant="outlined"
              value={formData.description}
              onChange={handleChange}
              disabled={loading}
              sx={{ mb: 2 }}
            />
            
            <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
              <InputLabel id="assignedTo-label">分配给</InputLabel>
              <Select
                labelId="assignedTo-label"
                id="assignedTo"
                name="assignedTo"
                value={formData.assignedTo}
                onChange={handleChange}
                label="分配给"
                disabled={loading}
              >
                <MenuItem value="">
                  <em>未分配</em>
                </MenuItem>
                {users.map((user) => (
                  <MenuItem key={user._id} value={user._id}>
                    {user.username}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            
            <DateTimePicker
              label="截止日期"
              value={formData.dueDate}
              onChange={handleDateChange}
              renderInput={(params) => <TextField {...params} fullWidth />}
              disabled={loading}
              sx={{ mb: 2 }}
            />
          </Box>
        </DialogContent>
        
        <DialogActions>
          <Button onClick={handleClose} disabled={loading}>
            取消
          </Button>
          <Button
            onClick={handleSubmit}
            variant="contained"
            disabled={loading}
            startIcon={loading ? <CircularProgress size={20} /> : null}
          >
            添加任务
          </Button>
        </DialogActions>
      </Dialog>
    </LocalizationProvider>
  );
};

export default TaskDialog;