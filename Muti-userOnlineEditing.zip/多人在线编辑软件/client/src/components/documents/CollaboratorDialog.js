import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  IconButton,
  Chip,
  Box,
  Typography,
  CircularProgress,
  Menu
} from '@mui/material';
import {
  PersonAdd as AddIcon,
  MoreVert as MoreVertIcon,
  Delete as DeleteIcon,
  Edit as EditIcon
} from '@mui/icons-material';
import documentService from '../../services/documentService';
import userService from '../../services/userService';

const CollaboratorDialog = ({ open, onClose, document, onCollaboratorsUpdated }) => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState('');
  const [permission, setPermission] = useState('read');
  const [collaboratorMenuAnchor, setCollaboratorMenuAnchor] = useState(null);
  const [selectedCollaborator, setSelectedCollaborator] = useState(null);
  const [permissionDialogOpen, setPermissionDialogOpen] = useState(false);
  const [newPermission, setNewPermission] = useState('');

  useEffect(() => {
    if (open && document) {
      // 重置表单
      setSearchQuery('');
      setSelectedUser('');
      setPermission('read');
    }
  }, [open, document]);

  const handleSearchUsers = async (query) => {
    setSearchQuery(query);
    
    if (!query.trim()) {
      setUsers([]);
      return;
    }
    
    setSearchLoading(true);
    try {
      const response = await userService.getUsers({ search: query, limit: 10 });
      // 过滤掉已经是协作者的用户和文档所有者
      const filteredUsers = response.data.users.filter(
        user => user._id !== document.owner._id &&
                !document.collaborators.some(c => c.user._id === user._id)
      );
      setUsers(filteredUsers);
    } catch (error) {
      console.error('搜索用户失败:', error);
    } finally {
      setSearchLoading(false);
    }
  };

  const handleAddCollaborator = async () => {
    if (!selectedUser) return;
    
    setLoading(true);
    try {
      await documentService.addCollaborator(document._id, {
        userId: selectedUser,
        permission
      });
      
      // 重置表单
      setSelectedUser('');
      setPermission('read');
      setSearchQuery('');
      setUsers([]);
      
      // 通知父组件更新
      onCollaboratorsUpdated && onCollaboratorsUpdated();
    } catch (error) {
      console.error('添加协作者失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCollaboratorMenuClick = (event, collaborator) => {
    setCollaboratorMenuAnchor(event.currentTarget);
    setSelectedCollaborator(collaborator);
  };

  const handleCollaboratorMenuClose = () => {
    setCollaboratorMenuAnchor(null);
    setSelectedCollaborator(null);
  };

  const handleUpdatePermission = () => {
    if (!selectedCollaborator || !newPermission) return;
    
    setLoading(true);
    try {
      documentService.updateCollaboratorPermission(
        document._id,
        selectedCollaborator.user._id,
        newPermission
      ).then(() => {
        handlePermissionDialogClose();
        handleCollaboratorMenuClose();
        onCollaboratorsUpdated && onCollaboratorsUpdated();
      }).catch(error => {
        console.error('更新协作者权限失败:', error);
      }).finally(() => {
        setLoading(false);
      });
    } catch (error) {
      console.error('更新协作者权限失败:', error);
      setLoading(false);
    }
  };

  const handleRemoveCollaborator = () => {
    if (!selectedCollaborator) return;
    
    setLoading(true);
    try {
      documentService.removeCollaborator(
        document._id,
        selectedCollaborator.user._id
      ).then(() => {
        handleCollaboratorMenuClose();
        onCollaboratorsUpdated && onCollaboratorsUpdated();
      }).catch(error => {
        console.error('移除协作者失败:', error);
      }).finally(() => {
        setLoading(false);
      });
    } catch (error) {
      console.error('移除协作者失败:', error);
      setLoading(false);
    }
  };

  const handleOpenPermissionDialog = () => {
    if (!selectedCollaborator) return;
    
    setNewPermission(selectedCollaborator.permission);
    setPermissionDialogOpen(true);
  };

  const handlePermissionDialogClose = () => {
    setPermissionDialogOpen(false);
    setNewPermission('');
  };

  const getPermissionLabel = (permission) => {
    switch (permission) {
      case 'read':
        return '只读';
      case 'write':
        return '编辑';
      case 'admin':
        return '管理';
      default:
        return permission;
    }
  };

  const getPermissionColor = (permission) => {
    switch (permission) {
      case 'read':
        return 'default';
      case 'write':
        return 'primary';
      case 'admin':
        return 'secondary';
      default:
        return 'default';
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>管理协作者</DialogTitle>
      
      <DialogContent>
        {/* 当前协作者列表 */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="h6" gutterBottom>
            当前协作者
          </Typography>
          
          {document.collaborators.length === 0 ? (
            <Typography variant="body2" color="text.secondary">
              暂无协作者
            </Typography>
          ) : (
            <List>
              {document.collaborators.map((collaborator) => (
                <ListItem key={collaborator.user._id}>
                  <ListItemAvatar>
                    <Avatar src={collaborator.user.avatar}>
                      {collaborator.user.username.charAt(0).toUpperCase()}
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={collaborator.user.username}
                    secondary={collaborator.user.email}
                  />
                  <Chip
                    label={getPermissionLabel(collaborator.permission)}
                    color={getPermissionColor(collaborator.permission)}
                    size="small"
                    sx={{ mr: 1 }}
                  />
                  <IconButton
                    edge="end"
                    onClick={(e) => handleCollaboratorMenuClick(e, collaborator)}
                  >
                    <MoreVertIcon />
                  </IconButton>
                </ListItem>
              ))}
            </List>
          )}
        </Box>
        
        {/* 添加新协作者 */}
        <Box>
          <Typography variant="h6" gutterBottom>
            添加协作者
          </Typography>
          
          <TextField
            fullWidth
            placeholder="搜索用户..."
            value={searchQuery}
            onChange={(e) => handleSearchUsers(e.target.value)}
            disabled={loading}
            sx={{ mb: 2 }}
          />
          
          {searchQuery && (
            <Box sx={{ mb: 2 }}>
              {searchLoading ? (
                <Box display="flex" justifyContent="center" p={2}>
                  <CircularProgress size={24} />
                </Box>
              ) : users.length === 0 ? (
                <Typography variant="body2" color="text.secondary" align="center" p={2}>
                  未找到匹配的用户
                </Typography>
              ) : (
                <List>
                  {users.map((user) => (
                    <ListItem
                      key={user._id}
                      button
                      selected={selectedUser === user._id}
                      onClick={() => setSelectedUser(user._id)}
                    >
                      <ListItemAvatar>
                        <Avatar src={user.avatar}>
                          {user.username.charAt(0).toUpperCase()}
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText
                        primary={user.username}
                        secondary={user.email}
                      />
                    </ListItem>
                  ))}
                </List>
              )}
            </Box>
          )}
          
          {selectedUser && (
            <Box display="flex" alignItems="center" gap={2} mb={2}>
              <FormControl sx={{ minWidth: 120 }}>
                <InputLabel id="permission-label">权限</InputLabel>
                <Select
                  labelId="permission-label"
                  value={permission}
                  onChange={(e) => setPermission(e.target.value)}
                  label="权限"
                  disabled={loading}
                >
                  <MenuItem value="read">只读</MenuItem>
                  <MenuItem value="write">编辑</MenuItem>
                  <MenuItem value="admin">管理</MenuItem>
                </Select>
              </FormControl>
              
              <Button
                variant="contained"
                startIcon={loading ? <CircularProgress size={20} /> : <AddIcon />}
                onClick={handleAddCollaborator}
                disabled={loading}
              >
                添加
              </Button>
            </Box>
          )}
        </Box>
      </DialogContent>
      
      <DialogActions>
        <Button onClick={onClose} disabled={loading}>
          关闭
        </Button>
      </DialogActions>
      
      {/* 协作者操作菜单 */}
      <Menu
        anchorEl={collaboratorMenuAnchor}
        open={Boolean(collaboratorMenuAnchor)}
        onClose={handleCollaboratorMenuClose}
      >
        <MenuItem onClick={handleOpenPermissionDialog}>
          <EditIcon fontSize="small" sx={{ mr: 1 }} />
          修改权限
        </MenuItem>
        <MenuItem onClick={handleRemoveCollaborator}>
          <DeleteIcon fontSize="small" sx={{ mr: 1 }} />
          移除协作者
        </MenuItem>
      </Menu>
      
      {/* 修改权限对话框 */}
      <Dialog open={permissionDialogOpen} onClose={handlePermissionDialogClose}>
        <DialogTitle>修改权限</DialogTitle>
        
        <DialogContent>
          <FormControl fullWidth variant="outlined" sx={{ mt: 2 }}>
            <InputLabel id="new-permission-label">权限</InputLabel>
            <Select
              labelId="new-permission-label"
              value={newPermission}
              onChange={(e) => setNewPermission(e.target.value)}
              label="权限"
              disabled={loading}
            >
              <MenuItem value="read">只读</MenuItem>
              <MenuItem value="write">编辑</MenuItem>
              <MenuItem value="admin">管理</MenuItem>
            </Select>
          </FormControl>
        </DialogContent>
        
        <DialogActions>
          <Button onClick={handlePermissionDialogClose} disabled={loading}>
            取消
          </Button>
          <Button
            onClick={handleUpdatePermission}
            variant="contained"
            disabled={loading}
            startIcon={loading ? <CircularProgress size={20} /> : null}
          >
            更新
          </Button>
        </DialogActions>
      </Dialog>
    </Dialog>
  );
};

export default CollaboratorDialog;