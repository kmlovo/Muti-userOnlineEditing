import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Box,
  Typography,
  CircularProgress
} from '@mui/material';
import documentService from '../../services/documentService';

const DocumentCreateDialog = ({ open, onClose, onDocumentCreated }) => {
  const [formData, setFormData] = useState({
    title: '',
    type: 'text',
    content: '',
    tags: [],
    isPublic: false
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // 清除该字段的错误
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.title.trim()) {
      newErrors.title = '标题不能为空';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setLoading(true);
    
    try {
      const response = await documentService.createDocument(formData);
      onDocumentCreated && onDocumentCreated(response.data.document);
      handleClose();
    } catch (error) {
      console.error('创建文档失败:', error);
      setErrors({
        submit: error.response?.data?.message || '创建文档失败'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setFormData({
      title: '',
      type: 'text',
      content: '',
      tags: [],
      isPublic: false
    });
    setErrors({});
    onClose();
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle>创建新文档</DialogTitle>
      
      <DialogContent>
        {errors.submit && (
          <Box sx={{ color: 'error.main', mb: 2 }}>
            {errors.submit}
          </Box>
        )}
        
        <Box component="form" onSubmit={handleSubmit}>
          <TextField
            autoFocus
            margin="dense"
            id="title"
            name="title"
            label="文档标题"
            type="text"
            fullWidth
            variant="outlined"
            value={formData.title}
            onChange={handleChange}
            error={!!errors.title}
            helperText={errors.title}
            disabled={loading}
            sx={{ mb: 2 }}
          />
          
          <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
            <InputLabel id="type-label">文档类型</InputLabel>
            <Select
              labelId="type-label"
              id="type"
              name="type"
              value={formData.type}
              onChange={handleChange}
              label="文档类型"
              disabled={loading}
            >
              <MenuItem value="text">文本文档</MenuItem>
              <MenuItem value="markdown">Markdown文档</MenuItem>
            </Select>
          </FormControl>
          
          <TextField
            margin="dense"
            id="content"
            name="content"
            label="初始内容（可选）"
            multiline
            rows={4}
            fullWidth
            variant="outlined"
            value={formData.content}
            onChange={handleChange}
            disabled={loading}
            sx={{ mb: 2 }}
          />
        </Box>
      </DialogContent>
      
      <DialogActions>
        <Button onClick={handleClose} disabled={loading}>
          取消
        </Button>
        <Button
          onClick={handleSubmit}
          variant="contained"
          disabled={loading}
          startIcon={loading ? <CircularProgress size={20} /> : null}
        >
          创建
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DocumentCreateDialog;