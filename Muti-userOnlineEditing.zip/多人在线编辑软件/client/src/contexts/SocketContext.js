import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import io from 'socket.io-client';
import { useAuth } from './AuthContext';

const SocketContext = createContext();

export const useSocket = () => {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
};

export const SocketProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [connected, setConnected] = useState(false);
  const { isAuthenticated, user } = useAuth();

  // 连接到Socket.IO服务器
  useEffect(() => {
    if (isAuthenticated && user) {
      const token = localStorage.getItem('token');
      
      const newSocket = io(process.env.REACT_APP_SERVER_URL || 'http://localhost:5000', {
        auth: {
          token
        }
      });

      newSocket.on('connect', () => {
        console.log('Socket.IO 连接成功');
        setConnected(true);
      });

      newSocket.on('disconnect', () => {
        console.log('Socket.IO 连接断开');
        setConnected(false);
      });

      newSocket.on('error', (error) => {
        console.error('Socket.IO 错误:', error.message);
      });

      setSocket(newSocket);

      return () => {
        newSocket.close();
      };
    } else {
      // 如果用户未认证，关闭现有连接
      if (socket) {
        socket.close();
        setSocket(null);
        setConnected(false);
      }
    }
  }, [isAuthenticated, user]);

  // 加入文档房间
  const joinDocument = useCallback((documentId) => {
    if (socket && connected) {
      socket.emit('join-document', { documentId });
    }
  }, [socket, connected]);

  // 离开文档房间
  const leaveDocument = useCallback((documentId) => {
    if (socket && connected) {
      socket.emit('leave-document', { documentId });
    }
  }, [socket, connected]);

  // 发送文档变更
  const sendDocumentChange = useCallback((documentId, operation, version) => {
    if (socket && connected) {
      socket.emit('document-change', { documentId, operation, version });
    }
  }, [socket, connected]);

  // 发送光标位置更新
  const sendCursorUpdate = useCallback((documentId, cursor) => {
    if (socket && connected) {
      socket.emit('cursor-update', { documentId, cursor });
    }
  }, [socket, connected]);

  // 发送聊天消息
  const sendChatMessage = useCallback((documentId, message) => {
    if (socket && connected) {
      socket.emit('chat-message', { documentId, message });
    }
  }, [socket, connected]);

  const value = {
    socket,
    connected,
    joinDocument,
    leaveDocument,
    sendDocumentChange,
    sendCursorUpdate,
    sendChatMessage
  };

  return (
    <SocketContext.Provider value={value}>
      {children}
    </SocketContext.Provider>
  );
};